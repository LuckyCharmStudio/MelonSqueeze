﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{

    public float maxSpeed = 7;
    public float jumpTakeOffSpeed = 7;
    public float minGroundNormalY = 0.65f;
    public float speed = 15f;

    public float gravityModifier = 1f;

    protected Vector2 targetVelocity;
    protected Vector2 groundNormal;
    protected bool grounded;
    protected Rigidbody2D rb;
    protected Vector2 velocity;
    protected const float minMoveDistance = 0.001f;
    protected ContactFilter2D contactFilter;
    protected RaycastHit2D[] hitBuffer = new RaycastHit2D[16];
    protected const float shellRadius = .01f;
    protected List<RaycastHit2D> hitBufferList = new List<RaycastHit2D>(16);

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        contactFilter.useTriggers = false;
        contactFilter.SetLayerMask(Physics2D.GetLayerCollisionMask(gameObject.layer));
        contactFilter.useLayerMask = true;
    }

    void Update()
    {
        //targetVelocity = Vector2.zero;
        //ComputeVelocity ();
    }
    protected virtual void ComputeVelocity()
    {
        //Vector2 move = Vector2.zero;

        //move.x = Input.GetAxis("Horizontal");

        //if (Input.GetButtonDown("Jump") && grounded)
        //{
        //    velocity.y = jumpTakeOffSpeed;
        //}
        //else if (Input.GetButtonUp("Jump"))
        //{
         //   if (velocity.y > 0)
         //       velocity.y = velocity.y * .5f;
        //}

       // targetVelocity = move * maxSpeed;
    }

    void FixedUpdate()
    {
        velocity += gravityModifier * Physics2D.gravity * Time.deltaTime;
        velocity.x = targetVelocity.x;

        grounded = false;

        Vector2 deltaPosition = velocity * Time.deltaTime;

        Vector2 moveAlongGround = new Vector2(groundNormal.y, -groundNormal.x);

        Vector2 rollOnGround = new Vector2(-groundNormal.y, -groundNormal.x);

        Vector2 move = moveAlongGround * deltaPosition.x;

        Movement (move, false);

        move = Vector2.up * deltaPosition.y;

        Movement (move, true);

        

        if (Input.GetButtonDown("Jump") && grounded)
        {
            velocity.y = jumpTakeOffSpeed;
        }
        else if (Input.GetButtonUp("Jump"))
        {
            if (velocity.y > 0)
                velocity.y = velocity.y * .5f;
        }

        velocity.x = Input.GetAxis("Horizontal") * Time.fixedDeltaTime * speed;

        rb.MovePosition(rb.position + Vector2.right * velocity.x);
       
        targetVelocity = move * maxSpeed;

        

        if (grounded)
        {
            rb.AddForce(velocity * 500f);
        }
    }

    void Movement(Vector2 move, bool yMovement)
    {
        float distance = move.magnitude;

        if (distance > minMoveDistance)
        {
            int count = rb.Cast(move, contactFilter, hitBuffer, distance + shellRadius);
            hitBufferList.Clear();
            for (int i = 0; i < count; i++)
            {
                hitBufferList.Add(hitBuffer[i]);
            }
            for (int i = 0; i < hitBufferList.Count; i++)
            {
                Vector2 currentNormal = hitBufferList[i].normal;
                if (currentNormal.y > minGroundNormalY)
                {
                    grounded = true;
                    if (yMovement)
                    {
                        groundNormal = currentNormal;
                        currentNormal.x = 0;
                    }
                    
                }

                float projection = Vector2.Dot(velocity, currentNormal);
                if (projection < 0)
                {
                    velocity = velocity - projection * currentNormal;
                }

                float modifedDistance = hitBufferList[i].distance - shellRadius;
                distance = modifedDistance < distance ? modifedDistance : distance;
            }
        } 
        rb.position = rb.position + move.normalized * distance;
    }
}
